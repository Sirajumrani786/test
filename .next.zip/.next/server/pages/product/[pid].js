"use strict";
(() => {
var exports = {};
exports.id = 260;
exports.ids = [260];
exports.modules = {

/***/ 2418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Breadcrumb = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "breadcrumb",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "breadcrumb-list",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "icon-home"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: "All Gyms"
                    })
                ]
            })
        })
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Breadcrumb);


/***/ }),

/***/ 2381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _pid_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/footer/index.tsx
var footer = __webpack_require__(8173);
// EXTERNAL MODULE: ./layouts/Main.tsx
var Main = __webpack_require__(1659);
// EXTERNAL MODULE: ./components/breadcrumb/index.tsx
var breadcrumb = __webpack_require__(2418);
// EXTERNAL MODULE: ./components/products-featured/index.tsx
var products_featured = __webpack_require__(4171);
;// CONCATENATED MODULE: ./components/product-single/gallery/index.tsx

const Gallery = ({ images  })=>{
    const featImage = images[0];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "product-gallery",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "product-gallery__thumbs",
                children: images.map((image)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "product-gallery__thumb",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: image,
                            alt: ""
                        })
                    }, image)
                )
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "product-gallery__image",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: featImage,
                    alt: ""
                })
            })
        ]
    });
};
/* harmony default export */ const gallery = (Gallery);

;// CONCATENATED MODULE: ./components/product-single/content/index.tsx

const Content = ({ product  })=>{
    // const dispatch = useDispatch();
    // const [count, setCount] = useState<number>(1);
    // const [color, setColor] = useState<string>('');
    // const [itemSize, setItemSize] = useState<string>('');
    // const onColorSet = (e: string) => setColor(e);
    // const onSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => setItemSize(e.target.value);
    // const { favProducts } = useSelector((state: RootState) => state.user);
    // const isFavourite = some(favProducts, productId => productId === product.id);
    // const toggleFav = () => {
    //   dispatch(toggleFavProduct(
    //     {
    //       id: product.id,
    //     }
    //   ))
    // }
    // const addToCart = () => {
    //   const productToSave: ProductStoreType = {
    //     id: product.id,
    //     name: product.name,
    //     thumb: product.images ? product.images[0] : '',
    //     price: product.currentPrice,
    //     count: count,
    //     color: color,
    //     size: itemSize
    //   }
    //   const productStore = {
    //     count,
    //     product: productToSave
    //   }
    //   dispatch(addProduct(productStore));
    // }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "product-content",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product-content__intro",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                        className: "product__id",
                        children: [
                            "GYM ID:",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            product.id
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "product-on-sale",
                        children: "Gym"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "product__name",
                        children: product.name
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "product__prices",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                children: [
                                    "$",
                                    product.currentPrice
                                ]
                            }),
                            product.discount && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                children: [
                                    "$",
                                    product.price
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product-content__filters",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "product-filter-item",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Description:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    marginTop: "8px",
                                    lineHeight: "21px",
                                    fontSize: "12px"
                                },
                                children: "Many gyms offer health assessments and fitness tracking facilities to help members track their progress."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "product-filter-item",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Features:"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        style: {
                                            marginTop: "8px",
                                            lineHeight: "21px",
                                            fontSize: "12px"
                                        },
                                        children: "State-of-the-art equipment"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        style: {
                                            marginTop: "8px",
                                            lineHeight: "21px",
                                            fontSize: "12px"
                                        },
                                        children: "Personalized training programs"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        style: {
                                            marginTop: "8px",
                                            lineHeight: "21px",
                                            fontSize: "12px"
                                        },
                                        children: "Group fitness classes"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "product-filter-item",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Location:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    marginTop: "8px",
                                    lineHeight: "21px",
                                    fontSize: "12px"
                                },
                                children: "Conveniently located in the heart of the city."
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const content = (Content);

;// CONCATENATED MODULE: ./components/product-single/description/index.tsx

const Description = ({ show  })=>{
    const style = {
        display: show ? "flex" : "none"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        style: style,
        className: "product-single__description",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product-description-block",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Discover the Ultimate Fitness Experience"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Embark on a journey to transform your body and mind with our state-of-the-art gym facilities. Our premier gym offers a wide range of equipment and amenities to elevate your fitness journey to new heights."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "With our expert trainers and personalized workout plans, you'll achieve your fitness goals faster than ever before. Whether you're a seasoned athlete or new to fitness, our supportive community and motivating atmosphere will empower you to succeed."
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product-description-block",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        children: "Discover the Ultimate Fitness Experience"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Embark on a journey to transform your body and mind with our state-of-the-art gym facilities. Our premier gym offers a wide range of equipment and amenities to elevate your fitness journey to new heights."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "With our expert trainers and personalized workout plans, you'll achieve your fitness goals faster than ever before. Whether you're a seasoned athlete or new to fitness, our supportive community and motivating atmosphere will empower you to succeed."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const description = (Description);

;// CONCATENATED MODULE: external "react-rater"
const external_react_rater_namespaceObject = require("react-rater");
var external_react_rater_default = /*#__PURE__*/__webpack_require__.n(external_react_rater_namespaceObject);
;// CONCATENATED MODULE: ./utils/markup.ts
const createMarkup = (content)=>{
    return {
        __html: content
    };
};
/* harmony default export */ const markup = (createMarkup);

;// CONCATENATED MODULE: ./components/product-single/reviews/reviews-list/index.tsx



const ReviewsList = ({ reviews  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "reviews-list",
        children: reviews.map((review, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "review-item",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "review__avatar",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: review.avatar,
                            alt: "avatar"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "review__content",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: review.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_rater_default()), {
                                total: 5,
                                interactive: false,
                                rating: review.punctuation
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "review__comment",
                                dangerouslySetInnerHTML: markup(review.description)
                            })
                        ]
                    })
                ]
            }, index)
        )
    });
};
/* harmony default export */ const reviews_list = (ReviewsList);

;// CONCATENATED MODULE: external "react-stars"
const external_react_stars_namespaceObject = require("react-stars");
var external_react_stars_default = /*#__PURE__*/__webpack_require__.n(external_react_stars_namespaceObject);
;// CONCATENATED MODULE: ./components/product-single/reviews/punctuation/index.tsx


const Punctuation = ({})=>{
    // const percentageBar = (count: number) => {
    //   return (count * 100) / countOpinions;
    // }
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "product-punctuation",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "form-group",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                marginBottom: "10px"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "rating",
                                    children: "Rating"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((external_react_stars_default()), {
                                    count: 5,
                                    size: 24,
                                    color2: "#ffd700"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            placeholder: "Enter Your Name",
                            style: {
                                border: "1px solid #ccc",
                                padding: "8px",
                                borderRadius: "6px",
                                marginTop: "10px",
                                width: "100%"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                            // type="text" 
                            placeholder: "Enter Your Review",
                            style: {
                                border: "1px solid #ccc",
                                padding: "8px",
                                borderRadius: "6px",
                                marginTop: "10px",
                                width: "100%"
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    type: "submit",
                    style: {
                        backgroundColor: "#007bff",
                        color: "#fff",
                        border: "none",
                        padding: "10px 20px",
                        borderRadius: "6px",
                        cursor: "pointer",
                        marginTop: "10px"
                    },
                    children: "Submit"
                })
            ]
        })
    });
};
/* harmony default export */ const punctuation = (Punctuation);

;// CONCATENATED MODULE: ./components/product-single/reviews/index.tsx



const Reviews = ({ show , product  })=>{
    const style = {
        display: show ? "flex" : "none"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        style: style,
        className: "product-single__reviews",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(punctuation, {
                punctuation: product.punctuation.punctuation,
                countOpinions: product.punctuation.countOpinions,
                votes: product.punctuation.votes
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(reviews_list, {
                reviews: product.reviews
            })
        ]
    });
};
/* harmony default export */ const reviews = (Reviews);

// EXTERNAL MODULE: ./utils/server.ts
var server = __webpack_require__(9708);
;// CONCATENATED MODULE: ./pages/product/[pid].tsx











const getServerSideProps = async ({ query  })=>{
    const pid = query.pid;
    const res = await fetch(`${server/* server */.f}/api/product/${pid}`);
    const product = await res.json();
    return {
        props: {
            product
        }
    };
};
const Product = ({ product  })=>{
    const { 0: showBlock , 1: setShowBlock  } = (0,external_react_.useState)("description");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Main/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "product-single",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "product-single__content",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(gallery, {
                                    images: product.images
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(content, {
                                    product: product
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "product-single__info",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "product-single__info-btns",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setShowBlock("description")
                                            ,
                                            className: `btn btn--rounded ${showBlock === "description" ? "btn--active" : ""}`,
                                            children: "Description"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setShowBlock("reviews")
                                            ,
                                            className: `btn btn--rounded ${showBlock === "reviews" ? "btn--active" : ""}`,
                                            children: "Reviews (2)"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(description, {
                                    show: showBlock === "description"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(reviews, {
                                    product: product,
                                    show: showBlock === "reviews"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "product-single-page",
                children: /*#__PURE__*/ jsx_runtime_.jsx(products_featured/* default */.Z, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer/* default */.Z, {})
        ]
    });
};
/* harmony default export */ const _pid_ = (Product);


/***/ }),

/***/ 9708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ server)
/* harmony export */ });
const dev = "production" !== "production";
const server = dev ? "http://localhost:3000" : "https://next-ecommerce-front.vercel.app";


/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7561:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/styled-jsx");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6135:
/***/ ((module) => {

module.exports = require("use-onclickoutside");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,778,179,171], () => (__webpack_exec__(2381)));
module.exports = __webpack_exports__;

})();